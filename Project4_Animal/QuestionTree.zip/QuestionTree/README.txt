Nathan Taylor

I wanted to make a more general insertion algorithm, but it ended up being to hard. What I ended up doing was copying
the data from the node and switching it to another node rather than moving the actual nodes around. In order to do that,
I would have had to keep track of the node above the one I was switching, which ended up being more complicated than
was necessary for the project.

I liked that the project was pretty easy to understand and also quite short.

Time: 2.5 hrs
