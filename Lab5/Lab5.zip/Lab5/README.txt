Nathan Taylor

This was a cool lab, not very hard but the algorithms were cool.