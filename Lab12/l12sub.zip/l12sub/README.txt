Nathan Taylor

I wish I knew a good joke