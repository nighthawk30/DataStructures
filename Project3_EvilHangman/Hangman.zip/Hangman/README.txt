Nathan Taylor
This one was pretty conceptually hard. The first challenge was figuring out what was actually going on in the code.
I eventually realized that process_guess was doing all the work. It mostly took time to figure out how to do the
partitions. I also encountered a problem at the end where the program wasn't accounting for words with repeating letters.

I liked the idea of the game. I didn't like how many edge cases there are. It makes it a pain to code.
Time: 7 hours
